import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

public class TickerForm extends MIDlet implements CommandListener
{
	private Display display;
	private TextField usernameTF, passwordTF;
	private Command submitCommand, exitCommand;
	private Form loginForm;
	private Ticker messageTicker;
	private Alert statusAlert;
	
	public TickerForm()
	{
		usernameTF = new TextField("User name:", "", 50, TextField.ANY);
		passwordTF = new TextField("Password:", "", 50, TextField.ANY | TextField.PASSWORD);
		
		messageTicker = new Ticker("Welcome to MyPortal"); 
		
		loginForm = new Form("Sign In");
		loginForm.setTicker(messageTicker);
		loginForm.append(usernameTF);
		loginForm.append(passwordTF);
		
		exitCommand = new Command("Exit", Command.EXIT, 1);
		submitCommand = new Command("Submit", Command.SCREEN, 1);
		
		loginForm.addCommand(submitCommand);
		loginForm.addCommand(exitCommand);
		
		loginForm.setCommandListener(this);
	}
	
	public void startApp()
	{
		display = Display.getDisplay(this);
		display.setCurrent(loginForm);
	}
	
	public void pauseApp()
	{}
	
	public void destroyApp(boolean unconditional)
	{} 
	
	public void commandAction(Command choice, Displayable displayable)
	{
		if(choice == submitCommand)
		{
			String un = usernameTF.getString();
			String pass = passwordTF.getString();
			
			if(un.toLowerCase().equals("hello") && pass.toLowerCase().equals("hi"))
				statusAlert = new Alert("Sign In Successful", "Valid User name and Password", null, AlertType.CONFIRMATION);
			
			else
				statusAlert = new Alert("Authentication Error", "Invalid User name and Password", null, AlertType.ERROR);
			
			statusAlert.setTimeout(Alert.FOREVER);
			display.setCurrent(statusAlert, loginForm);
			destroyApp(false);
		}
		
		if (choice == exitCommand)
		{
			destroyApp(false);
			notifyDestroyed();
		}
	}
}
