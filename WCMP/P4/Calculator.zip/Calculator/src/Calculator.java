import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

public class Calculator extends MIDlet implements CommandListener
{
	private Display display;
	private TextField data1TF, data2TF;
	private Command menuCommand, exitCommand, performCommand;
	private Form calculatorForm;
	private List operationL;
	private StringItem res;
	
	public Calculator()
	{
		data1TF = new TextField("1st Number:", "", 10, TextField.NUMERIC);
		data2TF = new TextField("2nd Number:", "", 10, TextField.NUMERIC);
		
		res = new StringItem("", "");
		
		calculatorForm = new Form("Calculator");
		calculatorForm.append(data1TF);
		calculatorForm.append(data2TF);
		calculatorForm.append(res);
		
		exitCommand = new Command("Exit", Command.EXIT, 1);
		menuCommand = new Command("Submit", Command.SCREEN, 1);
		
		calculatorForm.addCommand(menuCommand);
		calculatorForm.addCommand(exitCommand);
		
		calculatorForm.setCommandListener(this);
		
		performCommand = new Command("Perform", Command.SCREEN, 1);
		
		operationL = new List("Operations", List.IMPLICIT);
		operationL.append("Add", null);
		operationL.append("Subtract", null);
		operationL.append("Multiply", null);
		operationL.append("Divide", null);
		operationL.addCommand(performCommand);
		operationL.setCommandListener(this);
	}
	
	public void startApp()
	{
		display = Display.getDisplay(this);
		display.setCurrent(calculatorForm);
	}
	
	public void pauseApp()
	{}
	
	public void destroyApp(boolean unconditional)
	{} 
	
	public void commandAction(Command choice, Displayable displayable)
	{
		if(choice == menuCommand)
		{
			display.setCurrent(operationL);
			destroyApp(false);
		}
		
		if (choice == exitCommand)
		{
			destroyApp(false);
			notifyDestroyed();
		}
		
		if(choice == performCommand)
		{
			int selection = operationL.getSelectedIndex();
			
			int d1 = Integer.parseInt(data1TF.getString());
			int d2 = Integer.parseInt(data2TF.getString());
			
			String r = "";
			
			switch(selection)
			{
				case 0: r = d1 + " + " + d2 + " = " + (d1+d2) + "\n"; 
						break;
						
				case 1: r = d1 + " - " + d2 + " = " + (d1-d2) + "\n";
						break;
						
				case 2: r = d1 + " * " + d2 + " = " + (d1*d2) + "\n";
						break;
						
				case 3: r = d1 + " / " + d2 + " = " + (d1/d2) + "\n";
						break;
						
				default: break;
			}
			
			res.setText(r);
			display.setCurrent(calculatorForm);
		}
	}
}
